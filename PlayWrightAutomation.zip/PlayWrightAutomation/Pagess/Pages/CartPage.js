exports.CartPage = 
class CartPage {

constructor(page) {

 this.page = page ;
 this.noOfProducts = '//tbody[@id="tbodyid"]/tr/td[12]'


}

async checkProductInCart(productName) {
   
   const productsInCart = this.page.$$(this.noOfProducts)
   for (const product of productsInCart) {
   console.log(await product.textcontent()) 
     if (productName=== await product.textcontent()) {

     return true ;
     break ;

     }

   }


}


}