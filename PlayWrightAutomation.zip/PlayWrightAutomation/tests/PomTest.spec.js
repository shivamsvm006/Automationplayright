import {test, expect} from '@playwright/test';
import { LoginPage } from '../Pagess/Pages/LoginPage';
import { HomePage } from '../Pagess/Pages/HomePage';
import { CartPage } from '../Pagess/Pages/CartPage';
import { clear } from 'console';

test ('test', async ({page})=>{
 
    // Login
    const login = new LoginPage(page);
    await login.gotoLoginPage();
    await login.login('shivam006' , '123456');

    // Home
    const home = new HomePage(page);
    await home.addProductToCart('Sony vaio i7'); 
    await home.gotoCart(); // Go to the cart

    // Cart
    const cart = new CartPage(page);
    const status = await cart.checkProductInCart('Sony vaio i7'); 
    expect(await status).toBe(true); 
});